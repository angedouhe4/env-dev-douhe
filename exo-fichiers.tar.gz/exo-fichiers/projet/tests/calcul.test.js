// test de la fonction somme
